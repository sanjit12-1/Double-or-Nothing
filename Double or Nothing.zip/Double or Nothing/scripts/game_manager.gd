class_name GameManager
extends RefCounted
enum State { READY, FLIPPING, DECISION, GAME_OVER, EDGE }
enum Outcome { HEADS, TAILS, EDGE }
const EDGE_DENOMINATOR := 10000
var state := State.READY
var reward := 0
var run_multiplier := 1.0
var insurance_used := false
var pending_outcome: Outcome = Outcome.HEADS
var debug_forced_outcome := -1
func begin_run() -> void:
	reward = 0
	run_multiplier = 1.0
	insurance_used = false
func can_flip() -> bool: return state == State.READY or state == State.GAME_OVER
func determine_outcome(rng: RandomNumberGenerator, win_chance: float) -> Outcome:
	if OS.is_debug_build() and debug_forced_outcome >= 0:
		pending_outcome = debug_forced_outcome
		debug_forced_outcome = -1
		return pending_outcome
	if rng.randi_range(1, EDGE_DENOMINATOR) == 1:
		pending_outcome = Outcome.EDGE
	else:
		pending_outcome = Outcome.HEADS if rng.randf() < win_chance else Outcome.TAILS
	return pending_outcome
func debug_force_edge() -> void:
	if OS.is_debug_build(): debug_forced_outcome = Outcome.EDGE
func resume_after_edge() -> void:
	state = State.DECISION if reward > 0 else State.READY
