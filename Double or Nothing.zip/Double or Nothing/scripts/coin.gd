class_name Coin
extends Control

enum Face { IDLE, HEADS, TAILS, EDGE }

const RIM := Color("c9a024")
const METAL := Color("e6c14a")
const METAL_DARK := Color("9a6e1c")
const FACE_HEADS := Color("f0d36a")
const FACE_TAILS := Color("c4922c")
const HIGHLIGHT := Color(1, 1, 1, 0.28)
const SHADOW := Color(0, 0, 0, 0.38)

var _face: Face = Face.IDLE
var _squash := 1.0
var _hop := 0.0
var _glow := 0.0
var _animating := false
var _elapsed := 0.0
var _duration := 0.8
var _intensity := 1.0
var _target_turns := 6.0
var _result: Face = Face.HEADS

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(112, 112)
	pivot_offset = custom_minimum_size * 0.5
	set_process(true)

func play_flip(duration: float, intensity: float, result: Face) -> void:
	_animating = true
	_elapsed = 0.0
	_duration = maxf(duration, 0.05)
	_intensity = intensity
	_result = result
	_glow = 0.0
	var halves := 6
	if intensity > 1.05:
		halves = 8
	if result == Face.EDGE:
		_target_turns = float(halves) + 0.5
	elif result == Face.TAILS:
		if halves % 2 == 0:
			halves += 1
		_target_turns = float(halves)
	else:
		if halves % 2 == 1:
			halves += 1
		_target_turns = float(halves)
	queue_redraw()

func settle(face: Face) -> void:
	_animating = false
	_face = face
	_hop = 0.0
	if face == Face.EDGE:
		_squash = 0.07
		_glow = 0.4
	else:
		_squash = 1.0
		_glow = 0.0
		if face == Face.IDLE:
			_face = Face.HEADS
	pivot_offset = size * 0.5
	queue_redraw()

func complete() -> void:
	var should_pop := _animating and _result != Face.EDGE
	_animating = false
	settle(_result)
	if should_pop:
		_play_land_pop()

func _process(delta: float) -> void:
	if _animating:
		_elapsed += delta
		var t := clampf(_elapsed / _duration, 0.0, 1.0)
		var eased := _spin_ease(t)
		var turns := eased * _target_turns
		_squash = absf(cos(turns * PI))
		if _result == Face.EDGE and t > 0.86:
			_squash = lerpf(_squash, 0.07, clampf((t - 0.86) / 0.14, 0.0, 1.0))
		else:
			_squash = maxf(_squash, 0.08)
		_face = Face.TAILS if int(floor(turns + 0.0001)) % 2 == 1 else Face.HEADS
		var lift := 14.0 * _intensity
		_hop = -sin(t * PI) * lift
		if t >= 0.86 and _result != Face.EDGE:
			var bounce := (t - 0.86) / 0.14
			var strength := 10.0 if _intensity > 1.05 else 6.0
			_hop = sin(bounce * PI) * strength * (1.0 - bounce)
		if t >= 1.0:
			complete()
		queue_redraw()
	elif _face == Face.EDGE:
		_glow = 0.28 + 0.18 * sin(Time.get_ticks_msec() * 0.005)
		queue_redraw()

func _spin_ease(t: float) -> float:
	if t < 0.16:
		var u := t / 0.16
		return 0.07 * u * u
	var u := (t - 0.16) / 0.84
	return 0.07 + 0.93 * (1.0 - pow(1.0 - u, 2.7))

func _play_land_pop() -> void:
	pivot_offset = size * 0.5
	var pop := 1.08 if _intensity > 1.05 else 1.045
	scale = Vector2(pop, pop)
	var tw := create_tween()
	tw.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(self, "scale", Vector2.ONE, 0.18 if _intensity > 1.05 else 0.14)

func _draw() -> void:
	if size.x < 4.0 or size.y < 4.0:
		return
	var center := Vector2(size.x * 0.5, size.y * 0.5 + _hop)
	var radius := minf(size.x, size.y) * 0.42
	draw_set_transform(center + Vector2(2.0, 7.0), 0.0, Vector2(_squash, 1.0))
	draw_circle(Vector2.ZERO, radius, SHADOW)
	draw_set_transform(center, 0.0, Vector2(_squash, 1.0))
	if _face == Face.EDGE or _glow > 0.01:
		draw_circle(Vector2.ZERO, radius * 1.22, Color(0.96, 0.73, 0.23, _glow * 0.45))
	draw_circle(Vector2.ZERO, radius, RIM)
	draw_circle(Vector2.ZERO, radius * 0.86, METAL_DARK)
	var face_color := FACE_HEADS
	if _face == Face.TAILS:
		face_color = FACE_TAILS
	elif _face == Face.EDGE:
		face_color = METAL
	draw_circle(Vector2.ZERO, radius * 0.78, face_color)
	draw_arc(Vector2.ZERO, radius * 0.78, 0.0, TAU, 48, Color(0.55, 0.38, 0.08, 0.35), 1.6, true)
	draw_arc(Vector2(-radius * 0.18, -radius * 0.28), radius * 0.55, deg_to_rad(200), deg_to_rad(320), 18, HIGHLIGHT, 3.2, true)
	if _squash > 0.42 and _face != Face.EDGE:
		var font := ThemeDB.fallback_font
		var mark := "H" if _face == Face.HEADS else "T"
		var font_size := 34
		var mark_size := font.get_string_size(mark, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
		draw_string(font, Vector2(-mark_size.x * 0.5, mark_size.y * 0.28), mark, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color("3a2a0a"))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
