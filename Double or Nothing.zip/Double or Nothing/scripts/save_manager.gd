class_name SaveManager
extends RefCounted
const PATH := "user://double_or_nothing.save"
static func defaults() -> Dictionary:
	return {"currency": 0, "upgrades": {"speed": 0, "fortune": 0, "payout": 0, "double": 0, "insurance": 0, "bank": 0}, "achievements": [], "secret_found": false, "stats": {"total_flips": 0, "total_wins": 0, "total_losses": 0, "current_streak": 0, "best_streak": 0, "current_double_streak": 0, "best_double_streak": 0, "total_doubles": 0, "successful_doubles": 0, "failed_doubles": 0, "highest_reward": 0, "highest_run_score": 0, "total_banked": 0, "edge_endings": 0, "achievements_unlocked": 0}}
static func load_data() -> Dictionary:
	if not FileAccess.file_exists(PATH): return defaults()
	var file := FileAccess.open(PATH, FileAccess.READ)
	var parsed = JSON.parse_string(file.get_as_text())
	if parsed is not Dictionary: return defaults()
	var data := defaults()
	for key in parsed:
		if key != "upgrades" and key != "stats" and key != "leaderboard": data[key] = parsed[key]
	if parsed.get("upgrades") is Dictionary:
		for key in parsed.upgrades: data.upgrades[key] = parsed.upgrades[key]
	if parsed.get("stats") is Dictionary:
		for key in parsed.stats: data.stats[key] = parsed.stats[key]
	data.currency = int(data.currency)
	for key in data.upgrades: data.upgrades[key] = int(data.upgrades[key])
	for key in data.stats: data.stats[key] = int(data.stats[key])
	return data
static func save_data(data: Dictionary) -> void:
	var file := FileAccess.open(PATH, FileAccess.WRITE)
	file.store_string(JSON.stringify(data))
