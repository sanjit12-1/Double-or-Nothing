class_name AchievementManager
extends RefCounted
const INFO := {"first_flip": ["FIRST FLIP", "Complete your first flip."], "first_win": ["FIRST WIN", "Win your first flip."], "first_double": ["FIRST DOUBLE", "Attempt DOUBLE for the first time."], "first_bank": ["FIRST BANK", "Bank your first reward."], "double_trouble": ["DOUBLE TROUBLE", "Complete a 5-DOUBLE streak."], "no_fear": ["NO FEAR", "Complete a 10-DOUBLE streak."], "greedy": ["GREEDY", "Reach a ×16 run multiplier."], "high_roller": ["HIGH ROLLER", "Reach a current reward of 10,000."], "hot_streak": ["HOT STREAK", "Reach 5 consecutive wins."], "unstoppable": ["UNSTOPPABLE", "Reach 10 consecutive wins."], "one_in_a_million": ["ONE IN A MILLION", "Reach 20 consecutive wins. Probability: 1 in 1,048,576."], "should_have_banked": ["SHOULD HAVE BANKED", "Lose 1,000 or more unbanked."], "impossible": ["THE IMPOSSIBLE", "The coin refused to choose."]}
static func unlock(data: Dictionary, id: String) -> bool:
	if id in data.achievements: return false
	data.achievements.append(id)
	return true
