class_name UpgradeManager
extends RefCounted
const INFO := {"speed": {"name":"⚡ FLIP SPEED", "desc":"Faster coin reveals.", "base": 80, "max": 4}, "fortune": {"name":"🍀 FORTUNE", "desc":"+1% actual win chance per level.", "base": 150, "max": 5}, "payout": {"name":"💰 PAYOUT", "desc":"+25% reward per level.", "base": 100, "max": 6}, "double": {"name":"🔥 DOUBLE", "desc":"Improves risk multiplier.", "base": 250, "max": 5}, "insurance": {"name":"🛡️ INSURANCE", "desc":"Protect one failed DOUBLE each run.", "base": 400, "max": 1}, "bank": {"name":"🏦 BANK BONUS", "desc":"+10% banked reward per level.", "base": 180, "max": 5}}
static func cost(key: String, level: int) -> int: return int(INFO[key].base * pow(1.72, level))
static func chance(u: Dictionary) -> float: return 0.50 + 0.01 * int(u.fortune)
static func payout(u: Dictionary) -> float: return 1.0 + 0.25 * int(u.payout)
static func double_multiplier(u: Dictionary) -> float:
	var levels := [2.0, 2.1, 2.25, 2.5, 2.75, 3.0]
	return levels[mini(int(u.double), levels.size() - 1)]
static func bank_multiplier(u: Dictionary) -> float: return 1.0 + 0.10 * int(u.bank)
static func flip_time(u: Dictionary) -> float: return maxf(0.32, 0.82 - 0.12 * int(u.speed))
