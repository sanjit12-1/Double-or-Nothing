extends Control
const Save = preload("res://scripts/save_manager.gd")
const Upgrades = preload("res://scripts/upgrade_manager.gd")
const Achievements = preload("res://scripts/achievement_manager.gd")
const Game = preload("res://scripts/game_manager.gd")
const CoinView = preload("res://scripts/coin.gd")
var data: Dictionary
var game := Game.new()
var rng := RandomNumberGenerator.new()
var title_label: Label
var status_label: Label
var coin_label: Label
var coin: Coin
var coin_slot: CenterContainer
var stats_label: Label
var reward_block: VBoxContainer
var reward_caption: Label
var reward_label: Label
var meta_label: Label
var action_box: VBoxContainer
var page_col: VBoxContainer
var body_scroll: ScrollContainer
var toast: Label
var game_shell: Control
var menu_layer: Control
var init_layer: Control
var init_label: Label
var menu_title: VBoxContainer
var bg_glow: TextureRect
var nav_buttons: Dictionary = {}
var shop_rows: Dictionary = {}
var achievement_notification_active := false
var achievement_notification_id := 0
const INK := Color("e9e7df")
const MUTED := Color("969aa8")
const GOLD := Color("f6b93b")
const GREEN := Color("75e6a3")
const RED := Color("ff6676")
const BANK_TEAL := Color("8fd4c1")

func _ready() -> void:
	rng.randomize(); data = Save.load_data(); _build(); _show_main_menu()
func _exit_tree() -> void: Save.save_data(data)
func _build() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_add_backdrop()
	game_shell = MarginContainer.new()
	game_shell.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	game_shell.add_theme_constant_override("margin_left", 48)
	game_shell.add_theme_constant_override("margin_right", 48)
	game_shell.add_theme_constant_override("margin_top", 32)
	game_shell.add_theme_constant_override("margin_bottom", 24)
	game_shell.visible = false
	add_child(game_shell)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	game_shell.add_child(root)
	title_label = _label("DOUBLE OR NOTHING", 14, MUTED)
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(title_label)
	stats_label = _label("", 16, MUTED)
	stats_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stats_label.visible = false
	root.add_child(stats_label)
	body_scroll = ScrollContainer.new()
	body_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(body_scroll)
	var page_host := VBoxContainer.new()
	page_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body_scroll.add_child(page_host)
	page_col = VBoxContainer.new()
	page_col.custom_minimum_size = Vector2(520, 0)
	page_col.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	page_col.add_theme_constant_override("separation", 14)
	page_host.add_child(page_col)
	reward_block = VBoxContainer.new()
	reward_block.add_theme_constant_override("separation", 2)
	page_col.add_child(reward_block)
	reward_caption = _label("CURRENT REWARD", 12, MUTED)
	reward_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	reward_block.add_child(reward_caption)
	reward_label = _label("0", 76, GOLD)
	reward_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	reward_block.add_child(reward_label)
	coin_slot = CenterContainer.new()
	coin_slot.custom_minimum_size = Vector2(0, 120)
	page_col.add_child(coin_slot)
	coin = CoinView.new()
	coin_slot.add_child(coin)
	coin_label = _label("", 42, GOLD)
	coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	coin_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	coin_label.custom_minimum_size.y = 72
	coin_label.visible = false
	page_col.add_child(coin_label)
	status_label = _label("", 18, INK)
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	page_col.add_child(status_label)
	action_box = VBoxContainer.new()
	action_box.alignment = BoxContainer.ALIGNMENT_CENTER
	action_box.add_theme_constant_override("separation", 12)
	page_col.add_child(action_box)
	toast = _label("", 14, GOLD)
	toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(toast)
	meta_label = _label("", 14, MUTED)
	meta_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	meta_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(meta_label)
	var divider := HSeparator.new()
	divider.modulate = Color(1, 1, 1, 0.08)
	root.add_child(divider)
	var nav := HBoxContainer.new()
	nav.alignment = BoxContainer.ALIGNMENT_CENTER
	nav.add_theme_constant_override("separation", 6)
	root.add_child(nav)
	for item in [["GAME", "game"], ["UPGRADES", "shop"], ["ACHIEVEMENTS", "achievements"]]:
		var page_name: String = item[1]
		var nav_button := _button(item[0], show_page.bind(page_name), false, true, "nav")
		nav.add_child(nav_button)
		nav_buttons[page_name] = nav_button
	_build_menu()
	_build_init()
func _add_backdrop() -> void:
	var base := ColorRect.new()
	base.color = Color("08090d")
	base.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(base)
	var gradient := Gradient.new()
	gradient.offsets = PackedFloat32Array([0.0, 0.42, 1.0])
	gradient.colors = PackedColorArray([Color("1c1f2c"), Color("0c0e14"), Color("07080b")])
	var tex := GradientTexture2D.new()
	tex.gradient = gradient
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.22)
	tex.fill_to = Vector2(0.5, 1.02)
	tex.width = 128
	tex.height = 128
	var glow := TextureRect.new()
	glow.texture = tex
	glow.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	glow.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	glow.stretch_mode = TextureRect.STRETCH_SCALE
	glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(glow)
	bg_glow = glow
	var hair := ColorRect.new()
	hair.color = Color(0.96, 0.73, 0.23, 0.16)
	hair.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	hair.offset_bottom = 1.0
	hair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hair)
	_start_backdrop_idle()
func _start_backdrop_idle() -> void:
	if bg_glow == null: return
	var tw := bg_glow.create_tween()
	tw.set_loops()
	tw.set_trans(Tween.TRANS_SINE)
	tw.tween_property(bg_glow, "modulate", Color(1.12, 1.08, 0.96), 2.8)
	tw.tween_property(bg_glow, "modulate", Color(1, 1, 1), 2.8)
func _build_menu() -> void:
	menu_layer = Control.new()
	menu_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(menu_layer)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.add_child(center)
	var col := VBoxContainer.new()
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 10)
	col.custom_minimum_size = Vector2(420, 0)
	center.add_child(col)
	menu_title = VBoxContainer.new()
	menu_title.add_theme_constant_override("separation", 0)
	col.add_child(menu_title)
	var line1 := _label("DOUBLE", 56, GOLD)
	line1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	menu_title.add_child(line1)
	var line2 := _label("OR NOTHING", 34, INK)
	line2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	menu_title.add_child(line2)
	var tag := _label("EVERY FLIP IS A DECISION.", 15, MUTED)
	tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(tag)
	var gap := Control.new()
	gap.custom_minimum_size.y = 18
	col.add_child(gap)
	var play_btn := _button("PLAY", _enter_from_menu.bind("game"), true)
	play_btn.custom_minimum_size = Vector2(220, 58)
	play_btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	play_btn.add_theme_font_size_override("font_size", 22)
	col.add_child(play_btn)
	var gap2 := Control.new()
	gap2.custom_minimum_size.y = 6
	col.add_child(gap2)
	var upgrades_btn := _button("UPGRADES", _enter_from_menu.bind("shop"), false, true, "nav")
	upgrades_btn.custom_minimum_size = Vector2(180, 42)
	col.add_child(upgrades_btn)
	var achievements_btn := _button("ACHIEVEMENTS", _enter_from_menu.bind("achievements"), false, true, "nav")
	achievements_btn.custom_minimum_size = Vector2(180, 42)
	col.add_child(achievements_btn)
	var version := _label("JAM BUILD", 11, Color(0.59, 0.60, 0.66, 0.7))
	version.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	version.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	version.offset_top = -36
	version.offset_bottom = -18
	menu_layer.add_child(version)
	var title_idle := menu_title.create_tween()
	title_idle.set_loops()
	title_idle.set_trans(Tween.TRANS_SINE)
	title_idle.tween_property(menu_title, "modulate", Color(1.08, 1.04, 0.9), 2.4)
	title_idle.tween_property(menu_title, "modulate", Color.WHITE, 2.4)
func _build_init() -> void:
	init_layer = Control.new()
	init_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	init_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	init_layer.visible = false
	add_child(init_layer)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	init_layer.add_child(center)
	var col := VBoxContainer.new()
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 14)
	center.add_child(col)
	init_label = _label("INITIALIZING...", 16, MUTED)
	init_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(init_label)
	var bar_wrap := Control.new()
	bar_wrap.custom_minimum_size = Vector2(88, 8)
	col.add_child(bar_wrap)
	var bar := ColorRect.new()
	bar.color = GOLD
	bar.size = Vector2(18, 3)
	bar.position = Vector2(0, 3)
	bar_wrap.add_child(bar)
	var bar_tw := bar.create_tween()
	bar_tw.set_loops()
	bar_tw.tween_property(bar, "position:x", 70.0, 0.55).set_trans(Tween.TRANS_SINE)
	bar_tw.tween_property(bar, "position:x", 0.0, 0.55).set_trans(Tween.TRANS_SINE)
func _show_main_menu() -> void:
	menu_layer.visible = true
	init_layer.visible = false
	game_shell.visible = false
func _enter_from_menu(page: String) -> void:
	menu_layer.visible = false
	init_layer.visible = true
	init_layer.modulate.a = 1.0
	_run_init_dots()
	await get_tree().create_timer(0.7).timeout
	init_layer.visible = false
	game_shell.visible = true
	game_shell.modulate.a = 0.0
	if page == "game":
		show_game()
	elif page == "shop":
		show_shop()
	else:
		show_achievements()
	_fade_page()
	var tw := game_shell.create_tween()
	tw.tween_property(game_shell, "modulate:a", 1.0, 0.22)
func _run_init_dots() -> void:
	if init_label == null: return
	init_label.text = "INITIALIZING"
	var tw := init_label.create_tween()
	tw.set_loops(4)
	tw.tween_callback(func(): init_label.text = "INITIALIZING.")
	tw.tween_interval(0.16)
	tw.tween_callback(func(): init_label.text = "INITIALIZING..")
	tw.tween_interval(0.16)
	tw.tween_callback(func(): init_label.text = "INITIALIZING...")
	tw.tween_interval(0.16)
func _style(color: Color, radius: int, border := Color.TRANSPARENT, pad_h := 18, pad_v := 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.corner_radius_top_left = radius
	s.corner_radius_top_right = radius
	s.corner_radius_bottom_left = radius
	s.corner_radius_bottom_right = radius
	s.border_width_left = 1
	s.border_width_right = 1
	s.border_width_top = 1
	s.border_width_bottom = 1
	s.border_color = border
	s.content_margin_left = pad_h
	s.content_margin_right = pad_h
	s.content_margin_top = pad_v
	s.content_margin_bottom = pad_v
	return s
func _label(text: String, size: int, color: Color) -> Label:
	var l := Label.new(); l.text = text; l.add_theme_font_size_override("font_size", size); l.add_theme_color_override("font_color", color); return l
func _button(text: String, callback: Callable, primary := true, enabled := true, kind := "") -> Button:
	var radius := 12
	var pad_v := 12
	var font_color := Color("101218") if primary else INK
	var normal_color := Color("d6a43a")
	var hover_color := Color("edbe54")
	var pressed_color := Color("af7d1e")
	var border := Color(1, 1, 1, 0.08)
	if kind == "nav":
		radius = 10
		pad_v = 8
		font_color = MUTED
		normal_color = Color(1, 1, 1, 0.0)
		hover_color = Color(1, 1, 1, 0.06)
		pressed_color = Color(1, 1, 1, 0.10)
		border = Color(1, 1, 1, 0.0)
	elif kind == "bank":
		font_color = BANK_TEAL
		normal_color = Color("12201c")
		hover_color = Color("1a2e28")
		pressed_color = Color("0d1714")
		border = Color(0.56, 0.83, 0.76, 0.32)
	elif kind == "risk":
		font_color = Color("ffd4a8")
		normal_color = Color("2a1714")
		hover_color = Color("3a1e19")
		pressed_color = Color("1d100e")
		border = Color(0.92, 0.42, 0.38, 0.38)
	elif kind == "buy":
		radius = 10
		pad_v = 8
		font_color = Color("101218")
		normal_color = Color("d6a43a")
		hover_color = Color("edbe54")
		pressed_color = Color("af7d1e")
		border = Color(1, 1, 1, 0.10)
	elif not primary:
		font_color = INK
		normal_color = Color("161a24")
		hover_color = Color("1f2533")
		pressed_color = Color("10141c")
		border = Color(1, 1, 1, 0.06)
	var normal_style: StyleBoxFlat = _style(normal_color, radius, border, 18, pad_v)
	if kind == "buy":
		normal_style.shadow_color = Color(0.84, 0.64, 0.23, 0.16)
		normal_style.shadow_size = 8
		normal_style.shadow_offset = Vector2(0, 2)
	elif primary and kind == "":
		normal_style.shadow_color = Color(0.84, 0.64, 0.23, 0.18)
		normal_style.shadow_size = 12
		normal_style.shadow_offset = Vector2(0, 3)
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 46 if kind == "nav" else 50)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER if kind == "nav" or kind == "buy" else Control.SIZE_EXPAND_FILL
	if kind == "nav":
		b.custom_minimum_size.x = 156
	if kind == "buy":
		b.custom_minimum_size = Vector2(128, 42)
	b.add_theme_font_size_override("font_size", 14 if kind == "nav" else (14 if kind == "buy" else 16))
	b.add_theme_color_override("font_color", font_color)
	b.add_theme_color_override("font_hover_color", INK if kind == "nav" else font_color)
	b.add_theme_color_override("font_pressed_color", font_color)
	b.add_theme_color_override("font_disabled_color", Color(0.42, 0.44, 0.50))
	b.add_theme_stylebox_override("normal", normal_style)
	b.add_theme_stylebox_override("hover", _style(hover_color, radius, border, 18, pad_v))
	b.add_theme_stylebox_override("pressed", _style(pressed_color, radius, border, 18, pad_v))
	b.add_theme_stylebox_override("focus", _style(hover_color, radius, border, 18, pad_v))
	var disabled_style := _style(Color("12151c"), radius, Color(1, 1, 1, 0.04), 18, pad_v)
	b.add_theme_stylebox_override("disabled", disabled_style)
	b.disabled = not enabled
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	b.pressed.connect(callback)
	_wire_button(b)
	return b
func _wire_button(b: Button) -> void:
	b.resized.connect(func(): b.pivot_offset = b.size * 0.5)
	b.mouse_entered.connect(func():
		if b.disabled: return
		_tween_scale(b, 1.03)
	)
	b.mouse_exited.connect(func(): _tween_scale(b, 1.0))
	b.button_down.connect(func():
		if b.disabled: return
		_tween_scale(b, 0.97)
	)
	b.button_up.connect(func(): _tween_scale(b, 1.03 if b.is_hovered() and not b.disabled else 1.0))
func _tween_scale(target: Control, to: float) -> void:
	if not is_instance_valid(target): return
	target.pivot_offset = target.size * 0.5
	if target.has_meta("scale_tween"):
		var previous: Tween = target.get_meta("scale_tween")
		if previous != null: previous.kill()
	var tw := target.create_tween()
	tw.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(target, "scale", Vector2(to, to), 0.12)
	target.set_meta("scale_tween", tw)
func _fade_page() -> void:
	if not is_instance_valid(page_col): return
	page_col.modulate.a = 0.0
	var tw := page_col.create_tween()
	tw.tween_property(page_col, "modulate:a", 1.0, 0.18)
func _fade_status() -> void:
	if not is_instance_valid(status_label): return
	status_label.modulate.a = 0.0
	var tw := status_label.create_tween()
	tw.tween_property(status_label, "modulate:a", 1.0, 0.16)
func _emphasize_reward() -> void:
	await get_tree().process_frame
	if not is_instance_valid(reward_label): return
	if reward_label.has_meta("scale_tween"):
		var previous: Tween = reward_label.get_meta("scale_tween")
		if previous != null: previous.kill()
	reward_label.pivot_offset = reward_label.size * 0.5
	reward_label.scale = Vector2(1.08, 1.08)
	var tw := reward_label.create_tween()
	reward_label.set_meta("scale_tween", tw)
	tw.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(reward_label, "scale", Vector2.ONE, 0.28)
func _highlight_nav(page: String) -> void:
	for key in nav_buttons:
		var button: Button = nav_buttons[key]
		var active: bool = key == page
		button.add_theme_color_override("font_color", GOLD if active else MUTED)
func _prepare_page(page: String) -> void:
	var is_game := page == "game"
	var is_shop := page == "shop"
	reward_block.visible = is_game
	meta_label.visible = is_game
	stats_label.visible = not is_game
	coin_slot.visible = is_game
	coin_label.visible = page == "achievements"
	status_label.visible = not is_shop
	body_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	_highlight_nav(page)
	page_col.custom_minimum_size.x = 600 if is_shop else 520
	if is_game:
		title_label.text = "DOUBLE OR NOTHING"
		title_label.add_theme_font_size_override("font_size", 14)
		title_label.add_theme_color_override("font_color", MUTED)
		action_box.add_theme_constant_override("separation", 12)
	elif is_shop:
		title_label.add_theme_font_size_override("font_size", 22)
		title_label.add_theme_color_override("font_color", INK)
		stats_label.add_theme_font_size_override("font_size", 16)
		stats_label.add_theme_color_override("font_color", GOLD)
		action_box.add_theme_constant_override("separation", 2)
	else:
		title_label.add_theme_font_size_override("font_size", 28)
		title_label.add_theme_color_override("font_color", INK)
		stats_label.add_theme_font_size_override("font_size", 16)
		stats_label.add_theme_color_override("font_color", MUTED)
		coin_label.add_theme_font_size_override("font_size", 42)
		action_box.add_theme_constant_override("separation", 12)
func clear_actions() -> void:
	shop_rows.clear()
	for child in action_box.get_children(): child.queue_free()
func show_page(next: String) -> void:
	clear_actions(); achievement_notification_active = false; toast.text = ""
	if next == "game": show_game()
	elif next == "shop": show_shop()
	elif next == "achievements": show_achievements()
	_fade_page()
func show_game() -> void:
	clear_actions(); _prepare_page("game"); var u: Dictionary = data.upgrades
	var shown_reward := 0 if game.state == Game.State.READY or game.state == Game.State.GAME_OVER else game.reward
	reward_label.text = _fmt(shown_reward)
	reward_label.add_theme_color_override("font_color", RED if game.state == Game.State.GAME_OVER else GOLD)
	var meta := "BANK  %s        BEST RUN  %s\nWIN CHANCE  %d%%" % [_fmt(data.currency), _fmt(data.stats.highest_run_score), roundi(Upgrades.chance(u) * 100)]
	if game.state == Game.State.DECISION:
		meta += "        STREAK %d  •  ×%.2f" % [data.stats.current_streak, game.run_multiplier]
		if int(u.insurance) > 0 and not game.insurance_used:
			meta += "        INSURANCE READY"
	meta_label.text = meta
	if game.state == Game.State.READY:
		coin.settle(Coin.Face.IDLE); status_label.modulate = INK
		status_label.text = "HEADS WINS  •  TAILS LOSES\nFlip at the displayed chance."
		var ready_flip_button := _button("FLIP", flip, true, game.can_flip()); ready_flip_button.custom_minimum_size = Vector2(260, 58); ready_flip_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; ready_flip_button.add_theme_font_size_override("font_size", 22); action_box.add_child(ready_flip_button)
	elif game.state == Game.State.GAME_OVER:
		coin.settle(Coin.Face.TAILS); status_label.modulate = RED
		status_label.text = "TAILS — LOST\nYour bank is safe. Start a new run."
		var retry_flip_button := _button("FLIP", flip, true, game.can_flip()); retry_flip_button.custom_minimum_size = Vector2(260, 58); retry_flip_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; retry_flip_button.add_theme_font_size_override("font_size", 22); action_box.add_child(retry_flip_button)
	elif game.state == Game.State.DECISION:
		coin.settle(Coin.Face.HEADS); status_label.modulate = GREEN
		status_label.text = "HEADS — WIN\nDOUBLE  → %s" % _fmt(roundi(game.reward * Upgrades.double_multiplier(u)))
		var choices := HBoxContainer.new(); choices.add_theme_constant_override("separation", 12)
		var bank_button := _button("BANK  +%s" % _fmt(roundi(game.reward * Upgrades.bank_multiplier(u))), bank, false, true, "bank")
		bank_button.custom_minimum_size.y = 58
		bank_button.add_theme_font_size_override("font_size", 17)
		var double_button := _button("DOUBLE  → %s" % _fmt(roundi(game.reward * Upgrades.double_multiplier(u))), double_down, true, true, "risk")
		double_button.custom_minimum_size.y = 58
		double_button.add_theme_font_size_override("font_size", 17)
		choices.add_child(bank_button); choices.add_child(double_button); action_box.add_child(choices)
	elif game.state == Game.State.FLIPPING:
		status_label.modulate = INK; status_label.text = "THE COIN IS IN THE AIR"
	else:
		coin.settle(Coin.Face.EDGE); status_label.modulate = GOLD
		status_label.text = "THE COIN LANDED...\n\nEDGE\n\nTHE IMPOSSIBLE\nThe coin refused to choose."; action_box.add_child(_button("CONTINUE", func(): game.resume_after_edge(); show_game()))
	_fade_status()

# Debug builds may call this from the Godot debugger to test EDGE; release builds ignore it.
func debug_force_next_edge() -> void:
	game.debug_force_edge()
func _coin_face_for_outcome() -> Coin.Face:
	if game.pending_outcome == Game.Outcome.EDGE:
		return Coin.Face.EDGE
	if game.pending_outcome == Game.Outcome.TAILS:
		return Coin.Face.TAILS
	return Coin.Face.HEADS
func flip() -> void:
	if not game.can_flip(): return
	data.stats.current_streak = 0; data.stats.current_double_streak = 0; game.begin_run(); game.determine_outcome(rng, Upgrades.chance(data.upgrades)); game.state = Game.State.FLIPPING; clear_actions(); status_label.modulate = INK; status_label.text = "THE COIN IS IN THE AIR"
	var wait := Upgrades.flip_time(data.upgrades)
	coin.play_flip(wait, 1.0, _coin_face_for_outcome())
	await get_tree().create_timer(wait).timeout
	coin.complete(); resolve_flip(false)
func double_down() -> void:
	if game.state != Game.State.DECISION: return
	game.determine_outcome(rng, Upgrades.chance(data.upgrades)); game.state = Game.State.FLIPPING; data.stats.total_doubles += 1; _unlock("first_double"); clear_actions(); status_label.modulate = INK; status_label.text = "RISKING %s..." % _fmt(game.reward)
	var wait := Upgrades.flip_time(data.upgrades)
	coin.play_flip(wait, 1.22, _coin_face_for_outcome())
	await get_tree().create_timer(wait).timeout
	coin.complete(); resolve_flip(true)
func resolve_flip(is_double: bool) -> void:
	data.stats.total_flips += 1; _unlock("first_flip")
	if game.pending_outcome == Game.Outcome.EDGE:
		data.stats.edge_endings += 1; data.secret_found = true; game.state = Game.State.EDGE; _unlock("impossible"); Save.save_data(data); show_game(); return
	var win: bool = game.pending_outcome == Game.Outcome.HEADS
	if win:
		data.stats.total_wins += 1; data.stats.current_streak += 1; data.stats.best_streak = maxi(data.stats.best_streak, data.stats.current_streak); _unlock("first_win")
		if is_double: game.reward = roundi(game.reward * Upgrades.double_multiplier(data.upgrades)); game.run_multiplier *= Upgrades.double_multiplier(data.upgrades); data.stats.successful_doubles += 1; data.stats.current_double_streak += 1; data.stats.best_double_streak = maxi(data.stats.best_double_streak, data.stats.current_double_streak)
		else: game.reward = roundi(100 * Upgrades.payout(data.upgrades)); game.run_multiplier = 1.0
		data.stats.highest_reward = maxi(data.stats.highest_reward, game.reward); data.stats.highest_run_score = maxi(data.stats.highest_run_score, game.reward)
		if data.stats.current_double_streak >= 5: _unlock("double_trouble")
		if data.stats.current_double_streak >= 10: _unlock("no_fear")
		if game.run_multiplier >= 16.0: _unlock("greedy")
		if game.reward >= 10000: _unlock("high_roller")
		if data.stats.current_streak >= 5: _unlock("hot_streak")
		if data.stats.current_streak >= 10: _unlock("unstoppable")
		if data.stats.current_streak >= 20: _unlock("one_in_a_million")
		game.state = Game.State.DECISION; _set_toast("WIN — THE RUN LIVES"); Save.save_data(data); show_game(); _emphasize_reward()
	else:
		data.stats.total_losses += 1; data.stats.current_streak = 0
		if is_double: data.stats.failed_doubles += 1
		if is_double: data.stats.current_double_streak = 0
		if is_double and int(data.upgrades.insurance) > 0 and not game.insurance_used: game.insurance_used = true; game.state = Game.State.DECISION; _set_toast("TAILS — INSURANCE SAVED YOUR RUN"); Save.save_data(data); show_game(); return
		if game.reward >= 1000: _unlock("should_have_banked")
		game.reward = 0; game.state = Game.State.GAME_OVER; status_label.text = "LOSS — THE UNBANKED RUN IS GONE."; _set_toast("Permanent bank remains %s" % _fmt(data.currency)); Save.save_data(data); show_game()
func bank() -> void:
	if game.state != Game.State.DECISION: return
	var amount := roundi(game.reward * Upgrades.bank_multiplier(data.upgrades)); data.currency += amount; data.stats.total_banked += amount; _unlock("first_bank"); game.state = Game.State.READY; _set_toast("BANKED %s" % _fmt(amount)); Save.save_data(data); show_game()
func _unlock(id: String) -> void:
	if Achievements.unlock(data, id):
		data.stats.achievements_unlocked = data.achievements.size()
		Save.save_data(data)
		_show_achievement_notification(Achievements.INFO[id][0])
func _set_toast(message: String) -> void:
	if not achievement_notification_active: toast.text = message
func _show_achievement_notification(title: String) -> void:
	achievement_notification_active = true; achievement_notification_id += 1; var notification_id: int = achievement_notification_id; toast.modulate = GOLD; toast.text = "ACHIEVEMENT UNLOCKED\n" + title
	var tween := get_tree().create_tween(); tween.tween_interval(2.4); tween.tween_property(toast, "modulate:a", 0.0, 0.35); tween.tween_callback(_clear_achievement_notification.bind(notification_id))
func _clear_achievement_notification(notification_id: int) -> void:
	if notification_id != achievement_notification_id: return
	achievement_notification_active = false; toast.text = ""; toast.modulate = Color(1, 1, 1, 1)
func _upgrade_display_name(raw: String) -> String:
	var i := 0
	while i < raw.length():
		if raw.unicode_at(i) < 128 and raw.unicode_at(i) != 32:
			return raw.substr(i).strip_edges()
		i += 1
	return raw
func _upgrade_effect_text(key: String, level: int) -> String:
	var snapshot: Dictionary = data.upgrades.duplicate()
	snapshot[key] = maxi(level, 0)
	match key:
		"speed":
			return "%.2fs" % Upgrades.flip_time(snapshot)
		"fortune":
			return "%d%% win chance" % roundi(Upgrades.chance(snapshot) * 100)
		"payout":
			return "×%.2f payout" % Upgrades.payout(snapshot)
		"double":
			return "×%.2f" % Upgrades.double_multiplier(snapshot)
		"insurance":
			return "Protects one failed DOUBLE" if int(snapshot.insurance) > 0 else "Inactive"
		"bank":
			return "×%.2f banked" % Upgrades.bank_multiplier(snapshot)
		_:
			return ""
func _make_shop_row(key: String) -> Control:
	var info: Dictionary = Upgrades.INFO[key]
	var wrap := VBoxContainer.new()
	wrap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wrap.add_theme_constant_override("separation", 6)
	var row := HBoxContainer.new()
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 18)
	wrap.add_child(row)
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 2)
	row.add_child(left)
	var name_label := _label(_upgrade_display_name(str(info.name)), 17, INK)
	left.add_child(name_label)
	var desc_label := _label(str(info.desc), 13, MUTED)
	desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	left.add_child(desc_label)
	var level_label := _label("", 13, GOLD)
	left.add_child(level_label)
	var ticks := HBoxContainer.new()
	ticks.add_theme_constant_override("separation", 4)
	for i in int(info.max):
		var tick := ColorRect.new()
		tick.custom_minimum_size = Vector2(16, 3)
		tick.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tick.color = Color(1, 1, 1, 0.12)
		ticks.add_child(tick)
	left.add_child(ticks)
	var current_label := _label("", 13, INK)
	left.add_child(current_label)
	var next_label := _label("", 13, MUTED)
	left.add_child(next_label)
	var side := VBoxContainer.new()
	side.alignment = BoxContainer.ALIGNMENT_CENTER
	side.custom_minimum_size.x = 124
	side.add_theme_constant_override("separation", 6)
	row.add_child(side)
	var cost_label := _label("", 13, GOLD)
	cost_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	cost_label.custom_minimum_size.x = 124
	side.add_child(cost_label)
	var buy_btn := _button("UPGRADE", buy.bind(key), true, true, "buy")
	side.add_child(buy_btn)
	var line := ColorRect.new()
	line.custom_minimum_size.y = 1
	line.color = Color(1, 1, 1, 0.06)
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wrap.add_child(line)
	shop_rows[key] = {
		"root": wrap,
		"level": level_label,
		"ticks": ticks,
		"current": current_label,
		"next": next_label,
		"cost": cost_label,
		"buy": buy_btn,
	}
	return wrap
func _refresh_shop_header() -> void:
	stats_label.text = "BANK  %s\nFortune is real and always shown." % _fmt(data.currency)
func _refresh_shop_row(key: String) -> void:
	if not shop_rows.has(key): return
	var info: Dictionary = Upgrades.INFO[key]
	var widgets: Dictionary = shop_rows[key]
	var level: int = int(data.upgrades[key])
	var max_level: int = int(info.max)
	var maxed := level >= max_level
	var cost := 0 if maxed else Upgrades.cost(key, level)
	var can_buy: bool = not maxed and data.currency >= cost
	var level_label: Label = widgets.level
	level_label.text = "LEVEL  %d / %d" % [level, max_level]
	level_label.add_theme_color_override("font_color", GOLD if not maxed else GREEN)
	var ticks: HBoxContainer = widgets.ticks
	for i in ticks.get_child_count():
		var tick: ColorRect = ticks.get_child(i)
		tick.color = GOLD if i < level else Color(1, 1, 1, 0.12)
	var current_label: Label = widgets.current
	current_label.text = "Current  %s" % _upgrade_effect_text(key, level)
	var next_label: Label = widgets.next
	next_label.visible = not maxed
	if not maxed:
		next_label.text = "Next  %s" % _upgrade_effect_text(key, level + 1)
	var cost_label: Label = widgets.cost
	if maxed:
		cost_label.text = "MAX"
		cost_label.add_theme_color_override("font_color", GREEN)
	else:
		cost_label.text = "%s coins" % _fmt(cost)
		cost_label.add_theme_color_override("font_color", GOLD if can_buy else MUTED)
	var buy_btn: Button = widgets.buy
	buy_btn.text = "MAX" if maxed else "UPGRADE"
	buy_btn.disabled = not can_buy
func _refresh_shop(purchased_key := "") -> void:
	_refresh_shop_header()
	for key in Upgrades.INFO:
		_refresh_shop_row(key)
	if purchased_key != "" and shop_rows.has(purchased_key):
		_pulse_shop_row(shop_rows[purchased_key])
func _pulse_shop_row(widgets: Dictionary) -> void:
	var root: Control = widgets.root
	var level_label: Control = widgets.level
	root.modulate = Color(1.12, 1.08, 0.92)
	var fade := root.create_tween()
	fade.tween_property(root, "modulate", Color.WHITE, 0.32)
	level_label.pivot_offset = level_label.size * 0.5
	level_label.scale = Vector2(1.08, 1.08)
	var pop := level_label.create_tween()
	pop.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	pop.tween_property(level_label, "scale", Vector2.ONE, 0.24)
func show_shop() -> void:
	clear_actions(); _prepare_page("shop"); title_label.text = "UPGRADES"
	_refresh_shop_header()
	for key in Upgrades.INFO:
		var upgrade_key: String = key
		action_box.add_child(_make_shop_row(upgrade_key))
		_refresh_shop_row(upgrade_key)
func buy(key: String) -> void:
	if not Upgrades.INFO.has(key) or not data.upgrades.has(key): return
	var level: int = int(data.upgrades[key]); var cost := Upgrades.cost(key, level)
	if level >= int(Upgrades.INFO[key].max) or int(data.currency) < cost: return
	data.currency = int(data.currency) - cost; data.upgrades[key] = level + 1; Save.save_data(data); toast.text = "UPGRADED " + Upgrades.INFO[key].name
	if shop_rows.is_empty():
		show_shop()
	else:
		_refresh_shop(key)
func show_achievements() -> void:
	_prepare_page("achievements"); title_label.text = "ACHIEVEMENTS"; coin_label.custom_minimum_size.y = 48; stats_label.text = "%d / %d UNLOCKED" % [data.achievements.size(), Achievements.INFO.size()]; coin_label.text = "✦"; coin_label.modulate = GOLD; status_label.modulate = INK; status_label.text = "Your luck leaves a record."
	for id in Achievements.INFO:
		var item: Array = Achievements.INFO[id]; var unlocked: bool = id in data.achievements; var l := _label(("✓  " if unlocked else "🔒  ") + item[0] + "\n   " + item[1], 17, GREEN if unlocked else MUTED); l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; action_box.add_child(l)
func _fmt(number: int) -> String:
	var negative := number < 0
	var digits := str(absi(number))
	var grouped := ""
	while digits.length() > 3:
		grouped = "," + digits.substr(digits.length() - 3, 3) + grouped
		digits = digits.substr(0, digits.length() - 3)
	grouped = digits + grouped
	return ("-" if negative else "") + grouped
